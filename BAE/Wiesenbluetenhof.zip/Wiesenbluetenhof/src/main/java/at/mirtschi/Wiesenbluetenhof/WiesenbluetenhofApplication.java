package at.mirtschi.Wiesenbluetenhof;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiesenbluetenhofApplication {

	public static void main(String[] args) {
		SpringApplication.run(WiesenbluetenhofApplication.class, args);
	}

}
