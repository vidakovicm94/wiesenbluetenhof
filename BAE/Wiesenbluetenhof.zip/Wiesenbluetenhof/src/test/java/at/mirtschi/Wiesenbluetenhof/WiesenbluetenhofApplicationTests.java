package at.mirtschi.Wiesenbluetenhof;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiesenbluetenhofApplicationTests {

	@Test
	void contextLoads() {
	}

}
